#!/bin/bash
max=10
ip=0.0.0.0
filename=dijkstra.html
filename2=oi.gz
port=50004
tempo=2



    GET "$ip:$port/$filename" 	
    GET "$ip:$port/$filename2" 
GET "$ip:$port/$filename" 	
    GET "$ip:$port/$filename2" 
GET "$ip:$port/$filename" 	
    GET "$ip:$port/$filename2" 
GET "$ip:$port/$filename" 	
    GET "$ip:$port/$filename2" 
GET "$ip:$port/$filename" 	
    GET "$ip:$port/$filename2" 
GET "$ip:$port/$filename" 	
    GET "$ip:$port/$filename2" 
GET "$ip:$port/$filename" 	
    GET "$ip:$port/$filename2" 
GET "$ip:$port/$filename" 	
    GET "$ip:$port/$filename2" 
GET "$ip:$port/$filename" 	
    GET "$ip:$port/$filename2" 
GET "$ip:$port/$filename" 	
    GET "$ip:$port/$filename2" 
GET "$ip:$port/$filename" 	
    GET "$ip:$port/$filename2" 
GET "$ip:$port/$filename" 	
    GET "$ip:$port/$filename2" 
GET "$ip:$port/$filename" 	
    GET "$ip:$port/$filename2" 

GET "$ip:$port/$filename" 	
    GET "$ip:$port/$filename2" 
GET "$ip:$port/$filename" 	
    GET "$ip:$port/$filename2" 

GET "$ip:$port/$filename" 	
    GET "$ip:$port/$filename2" 

